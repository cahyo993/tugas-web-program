<table width="100%" border="0" class="menu" style="width:100%" cellspacing="0" cellpadding="0">

	<tr>
		<td><a href="admin.php?tampilan=kelola_berita">Berita</a></td>
		<td><a href="admin.php?tampilan=kelola_iklan">Iklan</a></td>
		<td><a href="admin.php?tampilan=kelola_anggota">Anggota</a></td>
		<td><a href="perintah/logout.php">Logout</a></td>
	</tr>
</table>